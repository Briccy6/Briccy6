-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 28, 2021 at 11:45 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `abanyabuzima`
--

-- --------------------------------------------------------

--
-- Table structure for table `abanyabuzima_chating_tbl`
--

CREATE TABLE `abanyabuzima_chating_tbl` (
  `message_id` int(11) NOT NULL,
  `sender_idno` text NOT NULL,
  `receiver_idno` text NOT NULL,
  `message` text NOT NULL,
  `seen` text NOT NULL DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `abanyabuzima_chating_tbl`
--

INSERT INTO `abanyabuzima_chating_tbl` (`message_id`, `sender_idno`, `receiver_idno`, `message`, `seen`) VALUES
(1, '123456', '123', 'amakuru evode?????', 'yes'),
(2, '123', '123456', 'ni meza muvandi............\r\n', 'yes'),
(9, '6543234', '435345', 'hello!!!!!!!!!', 'yes'),
(10, '435345', '6543234', 'im fine', 'yes'),
(11, '435345', '6543234', 'u?', 'yes'),
(12, '123', '123456', 'hello wang ', 'yes'),
(13, '123', '123456', 'nonese wampaye kakadocument', 'yes'),
(14, '123456', '123', 'dont wory ndaje ndakaguha kuri email', 'no'),
(15, '123456', '123', 'ok', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `children_nutrition_tbl`
--

CREATE TABLE `children_nutrition_tbl` (
  `nutrition_id` int(11) NOT NULL,
  `citizen_id` int(11) NOT NULL,
  `weight` text NOT NULL,
  `height` text NOT NULL,
  `consellor_idno` text NOT NULL,
  `nutrition_status` text NOT NULL,
  `comment` text NOT NULL,
  `hospital/healthcenter` text NOT NULL,
  `registration_date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `children_nutrition_tbl`
--

INSERT INTO `children_nutrition_tbl` (`nutrition_id`, `citizen_id`, `weight`, `height`, `consellor_idno`, `nutrition_status`, `comment`, `hospital/healthcenter`, `registration_date`) VALUES
(1, 9, '40', '30', '123', 'red', 'bad', 'kiziguro', '0011-07-07'),
(2, 1, '10', '30', '123', 'green', '           good', 'muhura', '2021-11-25'),
(3, 10, '70', '80', '123456', 'yellow', '                   amazing                                                 ', 'kiziguro', '2021-11-27');

-- --------------------------------------------------------

--
-- Table structure for table `citizens_tbl`
--

CREATE TABLE `citizens_tbl` (
  `citizen_id` int(11) NOT NULL,
  `family_id` int(11) NOT NULL,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `gender` text NOT NULL,
  `date_of_birth` text NOT NULL,
  `maritial_status` text NOT NULL,
  `idno` text NOT NULL,
  `province` text NOT NULL,
  `district` text NOT NULL,
  `sector` text NOT NULL,
  `cell` text NOT NULL,
  `village` text NOT NULL,
  `consellor_idno` int(16) NOT NULL,
  `hospital/healthcenter` text NOT NULL,
  `living_status` text NOT NULL,
  `comment` text NOT NULL,
  `registration_date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `citizens_tbl`
--

INSERT INTO `citizens_tbl` (`citizen_id`, `family_id`, `fname`, `lname`, `gender`, `date_of_birth`, `maritial_status`, `idno`, `province`, `district`, `sector`, `cell`, `village`, `consellor_idno`, `hospital/healthcenter`, `living_status`, `comment`, `registration_date`) VALUES
(1, 13, 'munyaneza', 'vincent', 'Male', '2021-11-01', 'maried', '1234', 'east', 'gatsibo', 'muhura', 'bibare', 'muhura', 123, 'muhura', 'rwandan', '                  dfghjkl                                      ', '2021-11-24'),
(2, 2, 'dd', 'f', 'Male', '2021-11-11', 'single', '1236', 'fgh', 'gatsibo', 'muhura', 'bibare', 'maryohe', 123, 'muhura', 'rwandan', '                               dfghj                         ', '2021-11-11'),
(7, 1, 'kamera', 'man', 'Male', '2021-11-11', 'maried', '12369', 'east', 'karongi', 'muhura', 'bibare', 'muhura', 123, 'muhura', 'rwandan', 'wapi', '2021-12-02'),
(8, 2, 'NDAGIJIMANA', 'Claude', 'Male', '2021-11-11', 'maried', '123699', 'east', 'gasabo', 'muhura', 'bibare', 'maryohe', 123, 'muhura', 'rwandan', '                                  fghjkl                      ', '2021-12-02'),
(9, 1, 'nyiraneza', 'primitive', 'Female', '2021-11-18', 'single', '42343243', 'north', 'rulindo', 'tumba', 'bibare', 'kiziguro', 123, 'tumba', 'rwandan', '                    asdfghj                                    ', '2021-11-18'),
(10, 1, 'bagabo', 'faustin', 'Male', '2021-11-24', 'maried', '234567809876', 'north', 'rulindo', 'muhura', 'bibare', 'maryohe', 123, 'muhura', 'rwandan', '                       dfghjk                                 ', '2021-11-30'),
(11, 3, 'aron', 'done', 'Female', '2021-11-24', 'Single', '123', 'fgh', 'gatsibo', 'muhura', 'bibare', 'muhura', 123456, 'muhura', 'ugandan', '                          dfghj                              ', '2021-11-23');

-- --------------------------------------------------------

--
-- Table structure for table `families/house_holds_tbl`
--

CREATE TABLE `families/house_holds_tbl` (
  `family_id` int(11) NOT NULL,
  `father_fname` text NOT NULL,
  `father_lname` text NOT NULL,
  `father_idno` text NOT NULL,
  `mother_fname` text NOT NULL,
  `mother_lname` text NOT NULL,
  `mother_idno` text NOT NULL,
  `province` text NOT NULL,
  `district` text NOT NULL,
  `sector` text NOT NULL,
  `cell` text NOT NULL,
  `village` text NOT NULL,
  `consellor_idno` int(11) NOT NULL,
  `hospital/healthcenter` text NOT NULL,
  `registration_date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `families/house_holds_tbl`
--

INSERT INTO `families/house_holds_tbl` (`family_id`, `father_fname`, `father_lname`, `father_idno`, `mother_fname`, `mother_lname`, `mother_idno`, `province`, `district`, `sector`, `cell`, `village`, `consellor_idno`, `hospital/healthcenter`, `registration_date`) VALUES
(1, 'munyaneza', 'vincent', '123', 'mukashyaka', 'patricie', '234', 'east', 'gatsibo', 'muhura', 'bibare', 'maryohe', 123, 'kiziguro', '2021-11-25'),
(2, 'gasana', 'emanuel', '6767678767', 'godace', 'didaciane', '87456789', 'west', 'rutsiro', 'musebeya', 'gasusa', 'musasa', 123, 'muhura', '2021-11-24'),
(3, 'Twizeyimana', 'Evode', '1234', 'mukasugira', 'claire', '123', 'east', 'gatsibo', 'muhura', 'bibare', '324', 123, 'muhura', '2021-11-10'),
(4, 'Niyonkuru', 'Telesphore', '123455432', 'mukamana', 'litha', '98765345', 'kigali', 'gasabo', 'jali', 'nkusi', 'nyagasayo', 123456, 'muhura', '2021-11-22'),
(5, 'niyonkuru', 'Telesphore', '1234', 'nzitabakuze', 'ladislas', '435351', 'north', 'gakenke', 'musagara', 'kabare', 'bumbogo', 123456, 'kiziguro', '2021-11-27'),
(6, 'kamana', 'antoine', '8765434567', 'murekatete', 'dada', '87654345679', 'west', 'rusizi', 'kamembe', 'bare', 'modoka', 123456, 'gahini', '2021-11-27');

-- --------------------------------------------------------

--
-- Table structure for table `family_planning_tbl`
--

CREATE TABLE `family_planning_tbl` (
  `F_planning_id` int(11) NOT NULL,
  `family_id` int(11) NOT NULL,
  `contraception_method` text NOT NULL,
  `comment` text NOT NULL,
  `consellor_idno` int(11) NOT NULL,
  `registration_date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `family_planning_tbl`
--

INSERT INTO `family_planning_tbl` (`F_planning_id`, `family_id`, `contraception_method`, `comment`, `consellor_idno`, `registration_date`) VALUES
(1, 2, 'Tubal Ligation', 'sdfdsf', 123, '2021-11-11'),
(2, 1, 'Vaccination', 'good', 123, '2021-11-11'),
(3, 3, 'Tubal Ligation', 'good', 123, '2021-11-15'),
(4, 5, 'Condom', 'sdfdsf', 123, '2021-11-11'),
(6, 4, 'Vaccination', 'sdfghj', 123456, '2021-11-18'),
(7, 6, 'Tubal Ligation', 'vb', 123456, '2021-11-27');

-- --------------------------------------------------------

--
-- Table structure for table `health_consellors_tbl`
--

CREATE TABLE `health_consellors_tbl` (
  `consellor_id` int(11) NOT NULL,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `gender` text NOT NULL,
  `idno` text NOT NULL,
  `province` text NOT NULL,
  `district` text NOT NULL,
  `sector` text NOT NULL,
  `cell` text NOT NULL,
  `village` text NOT NULL,
  `hospital/healthcenter` text NOT NULL,
  `hospital/healthcenter_post` text NOT NULL,
  `registration_date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `health_consellors_tbl`
--

INSERT INTO `health_consellors_tbl` (`consellor_id`, `fname`, `lname`, `gender`, `idno`, `province`, `district`, `sector`, `cell`, `village`, `hospital/healthcenter`, `hospital/healthcenter_post`, `registration_date`) VALUES
(1, 'Twizeyimana', 'Evode', 'Male', '123', 'Eastern', 'Gatsibo', 'Kimironko', 'Rulindo', 'Munyana', 'muhura', 'hospital', '2021-11-01'),
(2, 'kamera', 'theos', 'male', '123456', 'west', 'gatsibo', 'muhura', 'bibare', 'maryohe', 'muhura', 'healthcenter', '2021-11-12'),
(3, 'barayavuga', 'innocent', 'male', '435345', 'east', 'gatsibo', 'murambi', 'murambi', 'cyeru', 'kiziguro', 'hospital', '12/11/2021'),
(4, 'mukamana', 'dafrose', 'Female', '6543234', 'east', 'gatsibo', 'kiziguro', 'ntatemwa', 'ntatemwa', 'kiziguro', 'hospital', '2021-11-22'),
(5, 'niyonkuru', 'Telesphore', 'Male', '657565575', 'kigali', 'gasabo', 'jali', 'bugarama', 'bugingo', 'muhura', 'healthcenter', '2021-11-27');

-- --------------------------------------------------------

--
-- Table structure for table `hospital/healthcenter_tbl`
--

CREATE TABLE `hospital/healthcenter_tbl` (
  `hospital/healthcenter_id` int(11) NOT NULL,
  `system_user_IDNo` text NOT NULL,
  `healthcenter/hospital_name` text NOT NULL,
  `post` text NOT NULL,
  `province` text NOT NULL,
  `district` text NOT NULL,
  `sector` text NOT NULL,
  `cell` text NOT NULL,
  `village` text NOT NULL,
  `registration_date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hospital/healthcenter_tbl`
--

INSERT INTO `hospital/healthcenter_tbl` (`hospital/healthcenter_id`, `system_user_IDNo`, `healthcenter/hospital_name`, `post`, `province`, `district`, `sector`, `cell`, `village`, `registration_date`) VALUES
(1, '1234', 'muhura', 'healthcenter', 'east', 'gatsibo', 'muhura', 'bibare', 'kayenzi', '2021-11-01'),
(2, '243234', 'kiziguro', 'hospital', 'east', 'gatsibo', 'muhura', 'bibare', 'maryohe', '2021-11-01'),
(4, '123', 'gahini', 'hospital', 'north', 'gicumbi', 'muhura', 'bibare', 'kayenzi', '2021-11-12'),
(5, '43254', 'musagara', 'healthcenter', 'north', 'gakenke', 'bumbogo', 'rusura', 'kamisi', '2021-11-27'),
(6, '43254', 'musagara', 'hospital', 'north', 'gakenke', 'bumbogo', 'rusura', 'kamisi', '2021-11-27');

-- --------------------------------------------------------

--
-- Table structure for table `patients_tbl`
--

CREATE TABLE `patients_tbl` (
  `patient_id` int(11) NOT NULL,
  `citizen_id` int(11) NOT NULL,
  `illness_date` text NOT NULL,
  `temperature` text NOT NULL,
  `symptoms` text NOT NULL,
  `desease` text NOT NULL,
  `aid/drugs_given` text NOT NULL,
  `amount_paid` text NOT NULL,
  `life_insurance` text NOT NULL,
  `weight` text NOT NULL,
  `height` text NOT NULL,
  `patient_transferred` text NOT NULL,
  `hospital/healthcenter` text NOT NULL,
  `comment` text NOT NULL,
  `patient_care_date` text NOT NULL,
  `consellor_idno` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patients_tbl`
--

INSERT INTO `patients_tbl` (`patient_id`, `citizen_id`, `illness_date`, `temperature`, `symptoms`, `desease`, `aid/drugs_given`, `amount_paid`, `life_insurance`, `weight`, `height`, `patient_transferred`, `hospital/healthcenter`, `comment`, `patient_care_date`, `consellor_idno`) VALUES
(1, 1, '2021-11-12', '10', 'we', 're', 'sfdsf', '800', 'RADIANT', '10', '30', 'no', 'muhura', '                                dfdfdf', '2021-11-18', '123'),
(2, 2, '2021-11-12', '38', 'fever', 'malaria', 'quarteme', '799', 'PRIME', '12', '28', 'yes', 'kiziguro', 'asdfghdfdfdf', '2021-11-22', '123'),
(3, 7, '2021-11-27', '37', 'weak', 'cholera', 'sino', '700', 'RSSB', '30', '20', 'yes', 'muhura', '                                dangerous', '2021-11-27', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `pregnant_women_tbl`
--

CREATE TABLE `pregnant_women_tbl` (
  `pregnant_id` int(11) NOT NULL,
  `family_id` int(11) NOT NULL,
  `consellor_idno` text NOT NULL,
  `months_of_pregnancy` text NOT NULL,
  `hospital/healthcenter` text NOT NULL,
  `comment` text NOT NULL,
  `pregnancy_status` text NOT NULL DEFAULT '\'yes\'',
  `registration_date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pregnant_women_tbl`
--

INSERT INTO `pregnant_women_tbl` (`pregnant_id`, `family_id`, `consellor_idno`, `months_of_pregnancy`, `hospital/healthcenter`, `comment`, `pregnancy_status`, `registration_date`) VALUES
(1, 12, '123', '8', 'gahini', 'yibarutse neza ntakibazoooooooooooooooo!!!!           ', 'No', '2021-04-08'),
(2, 11, '123', '9', 'muhura', 'good                 hhhhhhhhhhhhhhhhhh', 'Yes', '2021-11-11'),
(3, 1, '123', '1', 'muhura', '   dfghjk                             ', 'yes', '2021-11-11'),
(4, 3, '123', '1', 'muhura', 'she is still pregnant', 'yes', '2021-11-11'),
(5, 4, '123456', '5', 'kiziguro', '             fghjk                   ', 'yes', '2021-11-18');

-- --------------------------------------------------------

--
-- Table structure for table `users_tbl`
--

CREATE TABLE `users_tbl` (
  `user_id` int(11) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `post` text NOT NULL,
  `hospital/healthcenter` text NOT NULL,
  `idno` text NOT NULL,
  `block` text NOT NULL DEFAULT 'Block'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users_tbl`
--

INSERT INTO `users_tbl` (`user_id`, `username`, `password`, `post`, `hospital/healthcenter`, `idno`, `block`) VALUES
(1, 'rbc', 'rbc', 'rbc', 'all', '12343232', 'Unblock'),
(2, 'evode', 'evode', 'umunyabuzima', 'muhura', '123', 'Block'),
(3, 'barayavuga', 'barayavuga', 'umunyabuzima', 'kiziguro', '435345', 'Unblock'),
(4, 'kamera', 'kamera', 'umunyabuzima', 'muhura', '123456', 'Block'),
(5, 'muhura', 'muhura', 'healthcenter', 'muhura', '1234', 'Block'),
(6, 'muhura', 'muhura', 'hospital', 'muhura', '12345', 'Block'),
(7, 'kiziguro', 'kiziguro', 'hospital', 'kiziguro', '243234', 'Unblock'),
(8, 'mukamana', 'mukamana', 'umunyabuzima', 'kiziguro', '6543234', 'Unblock');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `abanyabuzima_chating_tbl`
--
ALTER TABLE `abanyabuzima_chating_tbl`
  ADD PRIMARY KEY (`message_id`);

--
-- Indexes for table `children_nutrition_tbl`
--
ALTER TABLE `children_nutrition_tbl`
  ADD PRIMARY KEY (`nutrition_id`);

--
-- Indexes for table `citizens_tbl`
--
ALTER TABLE `citizens_tbl`
  ADD PRIMARY KEY (`citizen_id`);

--
-- Indexes for table `families/house_holds_tbl`
--
ALTER TABLE `families/house_holds_tbl`
  ADD PRIMARY KEY (`family_id`);

--
-- Indexes for table `family_planning_tbl`
--
ALTER TABLE `family_planning_tbl`
  ADD PRIMARY KEY (`F_planning_id`);

--
-- Indexes for table `health_consellors_tbl`
--
ALTER TABLE `health_consellors_tbl`
  ADD PRIMARY KEY (`consellor_id`);

--
-- Indexes for table `hospital/healthcenter_tbl`
--
ALTER TABLE `hospital/healthcenter_tbl`
  ADD PRIMARY KEY (`hospital/healthcenter_id`);

--
-- Indexes for table `patients_tbl`
--
ALTER TABLE `patients_tbl`
  ADD PRIMARY KEY (`patient_id`);

--
-- Indexes for table `pregnant_women_tbl`
--
ALTER TABLE `pregnant_women_tbl`
  ADD PRIMARY KEY (`pregnant_id`);

--
-- Indexes for table `users_tbl`
--
ALTER TABLE `users_tbl`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `abanyabuzima_chating_tbl`
--
ALTER TABLE `abanyabuzima_chating_tbl`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `children_nutrition_tbl`
--
ALTER TABLE `children_nutrition_tbl`
  MODIFY `nutrition_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `citizens_tbl`
--
ALTER TABLE `citizens_tbl`
  MODIFY `citizen_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `families/house_holds_tbl`
--
ALTER TABLE `families/house_holds_tbl`
  MODIFY `family_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `family_planning_tbl`
--
ALTER TABLE `family_planning_tbl`
  MODIFY `F_planning_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `health_consellors_tbl`
--
ALTER TABLE `health_consellors_tbl`
  MODIFY `consellor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `hospital/healthcenter_tbl`
--
ALTER TABLE `hospital/healthcenter_tbl`
  MODIFY `hospital/healthcenter_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `patients_tbl`
--
ALTER TABLE `patients_tbl`
  MODIFY `patient_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pregnant_women_tbl`
--
ALTER TABLE `pregnant_women_tbl`
  MODIFY `pregnant_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users_tbl`
--
ALTER TABLE `users_tbl`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
